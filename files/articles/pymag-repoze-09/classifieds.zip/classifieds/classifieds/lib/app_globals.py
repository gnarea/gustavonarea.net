# -*- coding: utf-8 -*-
"""The application's Globals object"""

__all__ = ['Globals']


class Globals(object):
    """
    Act as a container for objects available throughout the life of the
    Application.
    
    One instance of Globals is created during application initialization and
    is available during requests via the 'g' variable
    
    """

    def __init__(self):
        """Do nothing, by default."""
        pass

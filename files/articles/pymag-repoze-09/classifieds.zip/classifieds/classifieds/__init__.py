# -*- coding: utf-8 -*-
"""The classifieds package"""

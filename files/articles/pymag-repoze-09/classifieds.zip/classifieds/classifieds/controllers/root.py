# -*- coding: utf-8 -*-
"""Main Controller"""

from tg import expose, flash, require, url, request, redirect, validate
from pylons.i18n import ugettext as _, lazy_ugettext as l_
from catwalk.tg2 import Catwalk
from repoze.what import predicates
from repoze.what.predicates import is_anonymous, has_permission

from classifieds.lib.base import BaseController
from classifieds.model import DBSession, metadata
from classifieds.controllers.error import ErrorController
from classifieds import model
from classifieds.controllers.secure import SecureController
from classifieds.lib.authz import user_is_poster

__all__ = ['RootController']


class RootController(BaseController):
    """
    The root controller for the classifieds application.
    
    All the other controllers and WSGI applications should be mounted on this
    controller. For example::
    
        panel = ControlPanelController()
        another_app = AnotherWSGIApplication()
    
    Keep in mind that WSGI applications shouldn't be mounted directly: They
    must be wrapped around with :class:`tg.controllers.WSGIAppController`.
    
    """
    secc = SecureController()
    
    admin = Catwalk(model, DBSession)
    
    error = ErrorController()

    @expose('classifieds.templates.index')
    def index(self):
        """Handle the front-page."""
        query = DBSession.query(model.Classified)
        all_classifieds = query.all()
        return dict(page='index', 
                    classifieds=all_classifieds)

    @expose('classifieds.templates.about')
    def about(self):
        """Handle the 'about' page."""
        return dict(page='about')

    @expose('classifieds.templates.authentication')
    def auth(self):
        """Display some information about auth* on this application."""
        return dict(page='auth')

    @expose('classifieds.templates.index')
    @require(predicates.has_permission('manage', msg=l_('Only for managers')))
    def manage_permission_only(self, **kw):
        """Illustrate how a page for managers only works."""
        return dict(page='managers stuff')

    @expose('classifieds.templates.index')
    @require(predicates.is_user('editor', msg=l_('Only for the editor')))
    def editor_user_only(self, **kw):
        """Illustrate how a page exclusive for the editor works."""
        return dict(page='editor stuff')

    @expose('classifieds.templates.login')
    def login(self, came_from=url('/')):
        """Start the user login."""
        login_counter = request.environ['repoze.who.logins']
        if login_counter > 0:
            flash(_('Wrong credentials'), 'warning')
        return dict(page='login', login_counter=str(login_counter),
                    came_from=came_from)
    
    @expose()
    def post_login(self, came_from=url('/')):
        """
        Redirect the user to the initially requested page on successful
        authentication or redirect her back to the login page if login failed.
        
        """
        if not request.identity:
            login_counter = request.environ['repoze.who.logins'] + 1
            redirect(url('/login', came_from=came_from, __logins=login_counter))
        userid = request.identity['repoze.who.userid']
        flash(_('Welcome back, %s!') % userid)
        redirect(came_from)

    @expose()
    def post_logout(self, came_from=url('/')):
        """
        Redirect the user to the initially requested page on logout and say
        goodbye as well.
        
        """
        flash(_('We hope to see you soon!'))
        redirect(came_from)
    
    @expose('classifieds.templates.register')
    @require(is_anonymous(msg='Only one account per user' \
                              ' is allowed'))
    def register(self):
        """Display the user registration form"""
        return {'page': 'user registration'}
    
    @expose()
    @require(is_anonymous(msg='Only one account per user' \
                              ' is allowed'))
    def add_user(self, username, fullname, email, passwd):
        # Defining the row
        user = model.User()
        user.user_name = username
        user.display_name = fullname
        user.email_address = email
        user.password = passwd
        # Including her in the "posters" group:
        query = DBSession.query(model.Group)\
                .filter(model.Group.group_name==u'posters')
        posters = query.one()
        posters.users.append(user)
        # Saving the row:
        DBSession.add(user)
        # Redirecting to the login form with a notification
        # message:
        flash('Account created! Please log in')
        redirect(url('/login'))
    
    @expose('classifieds.templates.view')
    def view(self, classified):
        query = DBSession.query(model.Classified)
        classified_obj = query.get(classified)
        # Is the user allowed to edit the classified?
        checker = user_is_poster()
        can_edit = checker.is_met(request.environ)
        return {'page': 'Classified page',
                'classified': classified_obj,
                'classified_id': classified,
                'can_edit': can_edit}
    
    @expose('classifieds.templates.add')
    @require(has_permission('add-classifieds'))
    def add(self):
        return {'page': 'Classified submission'}
    
    @expose()
    @require(has_permission('add-classifieds'))
    def add_classified(self, title, contents):
        new_classified = model.Classified()
        new_classified.classified_title = title
        new_classified.classified_contents = contents
        # Getting the poster's user object from
        # repoze.who's identity dict:
        identity = request.environ['repoze.who.identity']
        new_classified.poster = identity['user']
        # We're ready to insert the row:
        DBSession.add(new_classified)
        # Redirecting to the previous form with a 
        # notification message:
        flash('Classified "%s" successfully published!'
              % title)
        redirect(url('/'))
    
    @expose('classifieds.templates.edit')
    @require(user_is_poster())
    def edit(self, classified):
        query = DBSession.query(model.Classified)
        classified_obj = query.get(classified)
        return {'page': 'Classified edition page',
                'classified': classified_obj,
                'classified_id': classified}
    
    @expose()
    @require(user_is_poster())
    def edit_classified(self, classified, title, contents):
        # Fetching and updating the classified object:
        query = DBSession.query(model.Classified)
        classified_obj = query.get(classified)
        classified_obj.classified_title = title
        classified_obj.classified_contents = contents
        DBSession.update(classified_obj)
        # Notifying the user:
        flash('Classified "%s" updated!' % title)
        redirect(url('/view/%s' % classified))

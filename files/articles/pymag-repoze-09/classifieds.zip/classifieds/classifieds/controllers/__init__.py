# -*- coding: utf-8 -*-
"""Controllers for the classifieds application."""

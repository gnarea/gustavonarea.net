import os

from trac.web.main import dispatch_request as trac_app
from webtest import TestApp



def trac_with_env(environ, start_response):
    """WSGI middleware that sets up Trac."""
    root = os.path.dirname(__file__)
    environ['trac.env_path'] = os.path.join(root, "weesgo", "trac-env")
    
    return trac_app(environ, start_response)


class TestTrac(object):
    
    def __init__(self):
        self.app = TestApp(trac_with_env)
    
    def test_homepage(self):
        response = self.app.get("/")
        
        assert response.status_int == 200
        assert "Welcome to Trac 0.11.7" in response.html.body.h1.string
    
    def test_search(self):
        home_response = self.app.get("/")
        
        search_form = home_response.forms['login']
        search_form['q'] = "wsgi"
        
        search_response = search_form.submit(status=500)
        
        assert "Unsupported version control system" in search_response

# -*- coding: utf-8 -*-

from setuptools import setup, find_packages

setup(name="weesgo",
      version="0.1",
      author="Gustavo Narea",
      author_email="me@gustavonarea.net",
      packages=find_packages(exclude=[]),
      zip_safe=False,
      install_requires=[
        "Django == 1.1.1",
        "twod.wsgi",
        "PasteScript",
        "Trac == 0.11.7",
        "bzr",
        ],
      )

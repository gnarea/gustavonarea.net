from django.conf.urls.defaults import *
from django.contrib import admin

admin.autodiscover()

urlpatterns = patterns('',
    (r'^login/$', 'django.contrib.auth.views.login', {'template_name': "login.html"}),
    (r'^logout/$', 'django.contrib.auth.views.logout', {'next_page': "/"}),
    (r'^admin/', include(admin.site.urls)),
    
    (r"^$", "weesgo.views.index"),
    (r"^trac(/.*)", "weesgo.views.make_trac"),
)

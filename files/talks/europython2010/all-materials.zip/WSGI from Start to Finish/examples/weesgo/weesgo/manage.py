#!/usr/bin/env python
from os import path

from django.core.management import execute_manager
from paste.deploy import loadapp

from weesgo import __file__ as root_init

_ROOT_DIR = path.dirname(path.dirname(root_init))

if __name__ == "__main__":
    loadapp("config:%s/dev.ini" % _ROOT_DIR)
    from weesgo import settings
    execute_manager(settings)

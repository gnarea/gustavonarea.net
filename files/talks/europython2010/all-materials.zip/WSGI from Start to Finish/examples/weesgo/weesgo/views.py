# -*- coding: utf-8 -*-
"""
Django views.

"""
from django.shortcuts import render_to_response, redirect
from django.conf import settings
from django.template import RequestContext

from twod.wsgi import call_wsgi_app
from trac.web.main import dispatch_request as trac_app


def index(request):
    settings_dict = [(k, repr(getattr(settings, k))) for k in dir(settings)
                     if (k != "PROFANITIES_LIST" and not k.startswith("_"))]
    return render_to_response("index.html", {'settings': settings_dict},
                              RequestContext(request))


def make_trac(request, path_info):
    
    if path_info.startswith("/login"):
        return redirect(request.script_name + "/login/")
    elif path_info.startswith("/logout"):
        return redirect(request.script_name + "/logout/")
    
    request.environ['trac.env_path'] = settings.TRAC_PATH
    return call_wsgi_app(trac_app, request, path_info)



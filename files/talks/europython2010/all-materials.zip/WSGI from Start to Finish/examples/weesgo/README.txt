ABOUT WEESGO
============

Weesgo is a sample Django application using advanced WSGI features thanks to
twod.wsgi.

To install it, run:
    
    python setup.py develop
    python weesgo/manage.py syncdb

Then create a Trac environment at "./trac-env", like this:
    
    trac-admin trac-env initenv "Weesgo Test" sqlite:db/trac.db svn ./path

You'll then be ready to start serving this application. To do it with
PasteScript, run the `paster' command:
    
    paster serve --reload dev.ini

You can now start playing with it! Try the authentication mechanisms in the
Trac instance or change the settings (e.g., replace the "green" theme with the
"pink" one).

If there's something that doesn't make too much sense, make sure to read the
twod.wsgi documentation:
    
    http://packages.python.org/twod.wsgi/

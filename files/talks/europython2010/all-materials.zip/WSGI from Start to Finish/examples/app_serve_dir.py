"""
Insecure WSGI application that serves the files and directories under a
document root.

"""
import os
from wsgiref.simple_server import make_server


class ServeDirectory(object):

    def __init__(self, directory):
        self.directory = directory

    def __call__(self, environ, start_response):
        file_ = os.path.join(self.directory, environ['PATH_INFO'])
        
        headers = [("Content-Type", "text/plain")]
        
        if os.path.isfile(file_):
            status = "200 Here is your file"
            open_file = open(file_)
            body = environ['wsgi.file_wrapper'](open_file)
        
        elif os.path.isdir(file_):
            status = "200 Here is your directory"
            
            files = os.listdir(file_)
            body = "%s is a directory:\n\n" % file_
            body +="\n".join(files)
        
        else:
            status = "404 You are lost"
            body = "File %s not found" % environ['PATH_INFO']
    
    start_response(status, headers)
    return body


directory_app = ServeDirectory("/")

# Running the WSGI server:
httpd = make_server("", 8000, directory_app)
httpd.serve_forever()
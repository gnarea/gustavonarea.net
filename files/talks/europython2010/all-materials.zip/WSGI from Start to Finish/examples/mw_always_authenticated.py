"""
WSGI middleware which forces the wrapped application to assume that the user
is always authenticated with a fixed user name.

"""

import os
from wsgiref.simple_server import make_server

from trac.web.main import dispatch_request as trac_app



def trac_with_env(environ, start_response):
    """
    WSGI middleware that sets up Trac.
    
    This has nothing to do with WSGI; it's just the way Trac works.
    
    """
    root = os.path.dirname(__file__)
    environ['trac.env_path'] = os.path.join(root, "weesgo", "trac-env")
    
    return trac_app(environ, start_response)


class AlwaysAuthenticated(object):
    """
    WSGI middleware that always authenticates the user.
    
    In CGI and WSGI, REMOTE_USER is the variable that holds the user's
    identifier when the user has been authenticated.
    
    """
    
    def __init__(self, app, username):
        self.app = app
        self.username = username
    
    def __call__(self, environ, start_response):
        environ['REMOTE_USER'] = self.username
        return self.app(environ, start_response)


authn_app = AlwaysAuthenticated(trac_with_env, "gustavo")

# Running the WSGI server:
httpd = make_server("", 8004, authn_app)
httpd.serve_forever()

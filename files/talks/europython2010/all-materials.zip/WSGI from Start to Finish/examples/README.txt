These are the code examples used in the EuroPython 2010 tutorial "WSGI from
Start to Finish" by Gustavo Narea. All the code here is licensed under the
GNU General Public License v2.

Instructions to install the dependencies
========================================

It's recommended to use virtualenv to install all the dependencies in an
isolated Python environment, but you can install them system-wide if you
want to.


Weesgo
------ 

Weesgo is a Django project that demostrates how to use twod.wsgi, a library
to make WSGI a first-class citizen in Django.

To install it and all its dependencies, run the following commands from the
weesgo/ subdirectory:

  python setup.py develop
  python weesgo/manage.py syncdb
  trac-admin trac-env initenv "Weesgo Test" sqlite:db/trac.db svn ./path

Then, to run Weesgo, just run:

  paster serve --reload dev.ini


Install WordPress
-----------------

If you want to try the WordPress example, you'd need to install and configure
WordPress and its dependencies, which isn't exactly trivial but can be done
in 6 steps:

  1.- Download and extract it somewhere.
  2.- Install the MySQL server.
  3.- Install PHP 5 (CGI) and the MySQL 5 bindings.
  4.- Create a database for WordPress.
  5.- In the directory where you extracted WordPress:
      A.- Copy wp-config-sample.php to wp-config.php
      B.- Set the database-related variables.
  6.- Open run_wordpress.py and update the "root" variable. It must point to
      the directory where WordPress was extracted.

That's it. To run WordPress under WSGI, do:

  python run_wordpress.py

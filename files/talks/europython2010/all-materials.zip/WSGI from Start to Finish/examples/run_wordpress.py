"""
WordPress running as a WSGI application under CGI.

Remember: This is just an example on how to embed CGI applications in WSGI.
For a production environment, you probably want to configure the other
application in the Web server and use a WSGI application that proxies it.

Of course, this all will only be useful if you are going to filter those
applications with Python code!

"""

from os import getcwd, path
from wsgiref.simple_server import make_server

from paste.urlmap import URLMap
from paste.urlparser import StaticURLParser
from wphp import PHPApp

root = path.join(getcwd(), "wp")

# Configuring WordPress itself:
wp_app = PHPApp(root, php_options={'magic_quote_gpc': 'Off'})

# Let Paste serve the static files:
wp_images = StaticURLParser("%s/wp-includes/images" % root)
wp_js = StaticURLParser("%s/wp-includes/js" % root)

# Let's put it all together by mapping the three WSGI applications above to URL
# paths, thanks to the URLMap request dispatcher (which is a WSGI middleware):
wordpress = URLMap()
wordpress['/'] = wp_app
wordpress['/wp-includes/images'] = wp_images
wordpress['/wp-includes/js'] = wp_js


# Running the WSGI server:
httpd = make_server("", 8003, wordpress)
httpd.serve_forever()

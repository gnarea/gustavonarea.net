"""
WSGI middleware that refuses access to a given path unconditionally.

"""

import os
from wsgiref.simple_server import make_server

from trac.web.main import dispatch_request as trac_app



def trac_with_env(environ, start_response):
    """
    WSGI middleware that sets up Trac.
    
    This has nothing to do with WSGI; it's just the way Trac works.
    
    """
    root = os.path.dirname(__file__)
    environ['trac.env_path'] = os.path.join(root, "weesgo", "trac-env")
    
    return trac_app(environ, start_response)


def deny_access(environ, start_response):
    """WSGI application that returns 403 responses."""
    status = "403 You know you can't be here"
    body = 'No one can visit %s. <a href="/">Go back</a>.' % \
           environ['PATH_INFO']
    headers = [
        ("Content-Type", "text/html"),
        ("Content-Length", str(len(body)))
        ]
    
    start_response(status, headers)
    
    return [body]


class ProtectPath(object):
    """WSGI middleware that refuses access to a given path unconditionally."""
    
    def __init__(self, protected_app, protected_path):
        self.protected_app = protected_app
        self.protected_path = protected_path
    
    def __call__(self, environ, start_response):
        if environ['PATH_INFO'].startswith(self.protected_path):
	    app = deny_access
	else:
	    app = self.protected_app
	
	return app(environ, start_response)


trac = ProtectPath(trac_with_env, "/wiki")

# Running the WSGI server:
httpd = make_server("", 8007, trac)
httpd.serve_forever()

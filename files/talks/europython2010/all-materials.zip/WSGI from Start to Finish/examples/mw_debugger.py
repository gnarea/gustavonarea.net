"""
WSGI application that prints all the WSGI environ variables and their respective
responses on every request.

This can be extremelly useful for debugging in development servers. To debug in
a production environment, try writing to an specific file.

"""

import os
import pprint
from wsgiref.simple_server import make_server

from trac.web.main import dispatch_request as trac_app



def trac_with_env(environ, start_response):
    """
    WSGI middleware that sets up Trac.
    
    This has nothing to do with WSGI; it's just the way Trac works.
    
    """
    root = os.path.dirname(__file__)
    environ['trac.env_path'] = os.path.join(root, "weesgo", "trac-env")
    
    return trac_app(environ, start_response)


class StartResponseWrapper(object):
    """start_response() wrapper to store the headers."""
    
    def __init__(self, original_sr):
        self.original_sr = original_sr
        self.status = self.headers = None
    
    def __call__(self, status, headers, exc_info=None):
        self.status = status
        self.headers = headers
        return self.original_sr(status, headers, exc_info)


class AppDebugger(object):
    """WSGI middleware that pretty prints the requests and responses."""
    
    def __init__(self, app):
        self.app = app
    
    def __call__(self, environ, start_response):
        # We don't care about the static files:
        if environ['PATH_INFO'].startswith("/chrome/"):
	    return self.app(environ, start_response)
	
        print "=====", environ['PATH_INFO']
        pprint.pprint(environ)
        print "---"
        
        # Capturing and printing the response:
        sr_wrapper = StartResponseWrapper(start_response)
        body = self.app(environ, sr_wrapper)
        print sr_wrapper.status
        pprint.pprint(sr_wrapper.headers)
        
        return body


debugged_app = AppDebugger(trac_with_env)

# Running the WSGI server:
httpd = make_server("", 8005, debugged_app)
httpd.serve_forever()

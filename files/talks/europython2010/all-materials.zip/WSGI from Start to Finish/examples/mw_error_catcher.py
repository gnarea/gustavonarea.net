"""WSGI middleware that catches and reports exceptions."""

import os
import pprint
import sys
from wsgiref.simple_server import make_server

from trac.web.main import dispatch_request as trac_app



class ErrorCatcher(object):
    """WSGI middleware that catches and reports exceptions."""
    
    def __init__(self, app):
        self.app = app
    
    def __call__(self, environ, start_response):
        try:
	    return self.app(environ, start_response)
	except:
	    exc = sys.exc_info()
	    
	    status = "500 Internal Server Error"
	    body = "The following exception was caught:\n%s" % exc[1]
	    headers = [
	        ("Content-Type", "text/plain"),
	        ("Content-Length", str((len(body)))),
	        ]
	    
	    start_response(status, headers, exc)
	    return [body]


monitored_app = ErrorCatcher(trac_app)

# Running the WSGI server:
httpd = make_server("", 8006, monitored_app)
httpd.serve_forever()
